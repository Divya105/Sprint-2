package org.com.dao;


import org.com.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{


	/*@Query(name="totalMarks",value="select total(t.testMarks) from Test t")
 public  float getTotalMarks();

	@Query(name="testAssign",value="select assign(t.testAssign) from Test t")
	public String getTestAssign();*/

	/*public String getResult() {
		return "Result";
	}
	public String getAssignTest() {
		return "AssignTest";
	}*/

}
