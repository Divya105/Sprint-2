package org.com;

import org.apache.catalina.User;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;

@SpringBootTest
class OnlineTestSystemApplicationTests {

	RestTemplate restTemplate;

	@BeforeEach
	public void setUp() {
		restTemplate=new RestTemplate();
	}
	
	//@Test
	
	/*public void addUserRecord() {
		User user=new User();
		user.setUserId(7);
		user.setUserName("Aman");
		user.setUserPassword("aman@67");
		
		ResponseEntity<User> postForEntity= restTemplate.postForEntity
				("http://localhost:9090/user/addUser",user,User.class);
		
		Assertions.assertNotNull(postForEntity);
		logger.info("add user works");
	}
	
	
	public void updateUserProfile() {
		restTemplate.put("http://localhost:9090/user/updateUser",User.class);
	}
	*/

}